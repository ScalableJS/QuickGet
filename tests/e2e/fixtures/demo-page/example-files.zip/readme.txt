Fictional example archive for the QuickGet support walkthrough.
